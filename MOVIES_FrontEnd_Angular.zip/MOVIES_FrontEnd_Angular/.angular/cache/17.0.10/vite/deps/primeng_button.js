import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-JMOSVZDW.js";
import "./chunk-P6M3KWQL.js";
import "./chunk-CPGE5KBG.js";
import "./chunk-CCME6Y6N.js";
import "./chunk-6DZ4QNU3.js";
import "./chunk-D2KDYNCR.js";
import "./chunk-7VUP7FJ2.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
