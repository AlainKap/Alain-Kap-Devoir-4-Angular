import {
  InputText,
  InputTextModule
} from "./chunk-J3OEC5BC.js";
import "./chunk-HUMA3IKJ.js";
import "./chunk-D2KDYNCR.js";
import "./chunk-7VUP7FJ2.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
