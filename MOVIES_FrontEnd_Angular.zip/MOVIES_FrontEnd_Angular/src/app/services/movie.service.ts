import { HttpClient, HttpHeaders, HttpParams  } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Movie } from '../interfaces/movie.interface';
import { AuthService } from './auth.service';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MovieService {

  protected http = inject(HttpClient);
  protected authService = inject(AuthService);
  protected baseUri = 'http://localhost:4501/';
  protected entityName = 'movies';

  // Méthode utilitaire pour préparer les en-têtes
  protected getHeaders() {
    return new HttpHeaders({
      Authorization: 'Bearer '+this.authService.token
    });
  }

  public list(numberOfElement: number, page: number) {
    const offset = (page - 1) * numberOfElement;
        const params = new HttpParams()
      .set('offset', offset.toString())
      .set('limit', numberOfElement.toString());

    return this.http.get<any[]>(this.baseUri + this.entityName, { params });
  }

  public allmovies(page: number, itemsPerPage: number): Observable<any> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('itemsPerPage', itemsPerPage.toString());

    return this.http.get<any[]>(`${this.baseUri}movies`, { params });
  }

  read(id: string) {
    return this.http.get(`${this.baseUri}${this.entityName}/${id}`, { headers: this.getHeaders() });
  }

  public create(movie: Movie): Observable<any> {
    return this.http.post(`${this.baseUri}${this.entityName}`, movie, { headers: this.getHeaders() }).pipe(
      catchError(error => {
        console.error('Erreur au niveau de create dans movieService:', error);
        return throwError(error);
      })
    );
  }

  addmovie(movie: Movie): Observable<any> {
    return this.http.post(`${this.baseUri}${this.entityName}`, movie, { headers: this.getHeaders() }).pipe(
      catchError(error => {
        console.error('Erreur au niveau de addmovie dans movieService:', error);
        return throwError(error);
      })
    );
  }

  updatemovie(movie: Movie, id: number): Observable<Movie> {
    if (movie && movie.id) {
      return this.http.put<Movie>(`${this.baseUri}${this.entityName}/${id}`, movie, { headers: this.getHeaders() });
    } else {
      return throwError(new Error("L'ID du film est undefined"));
    }
  }

  remove(movie: Movie): Observable<any> {
    return this.http.delete(`${this.baseUri}${this.entityName}/${movie.id}`, { headers: this.getHeaders() });
  }

}
