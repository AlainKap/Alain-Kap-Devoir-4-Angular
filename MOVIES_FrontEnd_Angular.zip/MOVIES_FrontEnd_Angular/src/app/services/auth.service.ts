import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';
import { User } from '../interfaces/auth';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private http = inject(HttpClient);
  private baseUri = 'http://localhost:4501/';
  public token?: string;
  public decodedToken?: any;
  private roles: string[] = [];
  router = inject(Router);
  route = inject(ActivatedRoute);

  subscribe() {}
  private user = { name: 'John Doe' };

  setSecret(token: string) {
    this.token = token;
    try {
      this.decodedToken = jwtDecode<any>(token);
      this.roles = this.decodedToken.roles;

      const userId = this.decodedToken.sub;
      if (userId) {
        localStorage.setItem('userId', userId.toString());
      } else {
        console.error('UserId non trouvé dans le token');
      }
    } catch (error) {
      console.error('Erreur de décodage du token', error);
    }
  }

  getUserId(): number | null {
    const userId = localStorage.getItem('userId');
    return userId ? parseInt(userId, 10) : null;
  }

  getUserIdByEmail(email: string): Observable<number | null> {
    return this.http
      .post<{ userId?: number }>(`${this.baseUri}/getUserByEmail`, { email })
      .pipe(
        map((response) => response.userId || null),
        catchError((error) => {
          console.error(
            "Erreur lors de la récupération de l'userId par email",
            error
          );
          return of(null);
        })
      );
  }

  login(identifiant: string, motDePasse: string) {
    return this.http
      .post<{ secret: string }>(this.baseUri + 'login', {
        login: identifiant,
        password: motDePasse,
      })
      .pipe(
        tap((response) => {
          const token = response.secret;
          if (token) {
            this.setSecret(token);
            localStorage.setItem('token', token);
          }
        }),
        catchError((error) => {
          return throwError(
            () => new Error('Échec de la connexion ou token invalide.')
          );
        })
      );
  }

  public getToken(): string | null {
    return localStorage.getItem('token') || sessionStorage.getItem('token');
  }

  public getUserEmail(): string | null {
    return localStorage.getItem('userEmail');
  }

  registerUser(userDetails: User) {
    return this.http.post(`${this.baseUri}register`, { postData: userDetails });
  }

  getUserByEmail(email: string): Observable<User[]> {
    return this.http.post<User[]>(`${this.baseUri}userByEmail`, { email });
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }
    try {
      const decodedToken: any = jwtDecode(token);
      const now = Date.now() / 1000;
      if (decodedToken.exp < now) {
        // Le token a expiré
        console.log('Token expiré');
        return false;
      }
    } catch (error) {
      console.error('Erreur lors du décodage du token', error);
      return false;
    }
    return true;
  }

  disconnect() {
    this.token = undefined;
    this.decodedToken = undefined;
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

  hasRole(role: string) {
    return this.roles.includes(role);
  }
}
