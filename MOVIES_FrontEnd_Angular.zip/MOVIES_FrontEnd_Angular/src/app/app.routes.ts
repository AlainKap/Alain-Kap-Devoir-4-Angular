import { Routes } from '@angular/router';
import { MovieComponent } from './components/movie/movie.component';
import { AddMovieComponent } from './components/add-movie/add-movie.component';
// Import de HomeComponent enlevé puisque vous ne l'utilisez plus.
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { authGuard } from './guards/auth.guard';
import { NoAuthGuard } from './guards/no-auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: 'register',
    component: RegisterComponent,
    canActivate: [NoAuthGuard],
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'movies',
    component: MovieComponent,
  },
  {
    path: 'movies/new',
    component: AddMovieComponent,
  },
  {
    path: 'movies/:id',
    component: AddMovieComponent,
  },
];
