import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree => {
  const router = inject(Router);
  // Permet l'accès à '/login' et '/register' sans authentification
  if (state.url === '/login' || state.url === '/register') {
    return true;
  }
  return sessionStorage.getItem('email') ? true : router.createUrlTree(['login']);
};


