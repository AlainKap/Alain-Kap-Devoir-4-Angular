import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function startsWithCapital(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (!value) {
      return null;
    }
    const parts = value.split(' ');
    for (const part of parts) {
      if (part.length && !part[0].match(/[A-ZÀ-Ÿ]/)) {
        return { startsWithCapital: 'Le nom et le prénom doivent commencer par une majuscule.' };
      }
    }
    return null;
  };
}
