import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastModule } from 'primeng/toast';
import { LoginComponent } from './components/login/login.component';
import { AuthService } from './services/auth.service';
import { RegisterComponent } from './components/register/register.component';
import { ButtonModule } from 'primeng/button';
import { MovieService } from './services/movie.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RegisterComponent, RouterOutlet, FormsModule, RouterLink, ToastModule, LoginComponent, ButtonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title =''
  connected = false;

  authService = inject(AuthService);
  service = inject(MovieService);

  ngOnInit() {
    const token = localStorage.getItem("token");
    if (!token) {
      return;
    }
    this.authService.setSecret(token);
  }

  isConnected() {
    if (!this.authService.decodedToken) {
      return false;
    }
    if (this.authService.decodedToken.exp > new Date().getTime()) {
      this.authService.disconnect();
      return false;
    }
    return true;
  }
}
