import { Component, Input, inject } from '@angular/core';
import { AddMovieComponent } from '../add-movie/add-movie.component';
import { MovieService } from '../../services/movie.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Movie } from '../../interfaces/movie.interface';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { RegisterComponent } from '../register/register.component';
import { DialogModule } from 'primeng/dialog';
import { DialogService } from 'primeng/dynamicdialog';


@Component({
  selector: 'app-movie',
  standalone: true,
  templateUrl: './movie.component.html',
  styleUrl: './movie.component.scss',
  imports: [
    RouterLink,
    AddMovieComponent,
    RegisterComponent,
    FormsModule,
    CommonModule,
    ButtonModule,
    PaginatorModule,
    TableModule,
    DialogModule,
  ],
  providers: [DialogService]
})
export class MovieComponent {
  selectedMovie?: Movie;
  showForm = false;
  authService = inject(AuthService);
  serviceMovie = inject(MovieService);
  dialogService = inject(DialogService);
  showAddButton = false;
  showEditButton = false;
  showAddForm = false;
  router = inject(Router);
  route = inject(ActivatedRoute);
  currentlyEditingId!: number;
  totalMovies = 0;
  currentPage = 1;
  itemsPerPage = 4;
  count = 0;
  page = 1;
  totalPage = 0;
  pages = [];
  movies: Movie[] = [];
  searchText: string = '';

  ngOnInit() {
    this.getMovies(1, 4);
  }

  openAddMovieDialog(movie?: Movie) {
    const ref = this.dialogService.open(AddMovieComponent, {
      header: movie ? 'Éditer un film' : 'Ajouter un nouveau film',
      width: '70%',
      data: { movie: movie }
    });

    ref.onClose.subscribe((result: any) => {
      console.log('Dialog closed', result);
      this.getMovies(this.currentPage, this.itemsPerPage);
    });
  }

  getMovies(page: number, itemsPerPage: number) {
    this.serviceMovie.allmovies(page, itemsPerPage).subscribe({
      next: (result: any) => {
        this.movies = result.data;
        this.totalMovies = result.total;
        console.log('movies récupérés avec succès :', this.movies);
      },
      error: (error) => {
        console.error('Erreur lors de la récupération des movies :', error);
      },
    });
  }

  addItem(item: Movie) {
    this.serviceMovie.addmovie(item).subscribe({
      next: (result: any) => {
        console.log('movie ajouté avec succès:', result);
        this.movies.push(result.data);
        this.showAddButton = true;
        this.closeAddForm();
      },
      error: (error) => {
        console.error("Erreur lors de l'ajout du movie:", error);
      },
    });
  }

  removeItem(index: number, movie: Movie) {
    this.serviceMovie.remove(movie).subscribe({
      next: (response) => {
        console.log(response);
        this.movies.splice(index, 1);
      },
      error: (error) => {
        console.error('Erreur lors de la suppression du movie :', error);
      },
      complete: () => {
        console.log('Arrivé au bout');
      },
    });
  }

  edit(id: number) {
    console.log(id);
    this.router.navigateByUrl('/movies/' + id);
  }

  selectMovie(item: Movie) {
    this.selectedMovie = item;
  }

  closeAddForm() {
    this.showAddForm = false;
    this.showEditButton = false;
  }

  openAddForm() {
    this.selectedMovie = undefined;
    this.showForm = true;
  }

  openEditForm() {
    if (this.selectedMovie) {
      this.openAddMovieDialog(this.selectedMovie);
    }
  }

  closeForm() {
    this.showForm = false;
  }

  paginate(event: any) {
    const page = event.page + 1;
    const itemsPerPage = event.rows;
    this.getMovies(page, itemsPerPage);
  }

}
