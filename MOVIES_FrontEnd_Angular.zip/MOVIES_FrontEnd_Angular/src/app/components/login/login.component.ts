import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormsModule, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { AuthService } from '../../services/auth.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DividerModule } from 'primeng/divider';
import { CardModule } from 'primeng/card';
import { MessageService } from 'primeng/api';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, InputTextModule, DividerModule, ButtonModule, ReactiveFormsModule, CardModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {

  authService = inject(AuthService);
  private unsubscribe$ = new Subject<void>();
  fb = inject(FormBuilder);
  msgService = inject(MessageService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  login: string = "";
  password: any = "";
  errorMessage: string = "";

  loginForm = this.fb.group({
    email: ['', { validators: [Validators.required, Validators.email], updateOn: 'blur' }],
    password: ['', { validators: [Validators.required, Validators.pattern(/^\S*$/), Validators.minLength(2)], updateOn: 'blur' }],
  })


  get email() {return this.loginForm.controls['email'];}
  //get password() { return this.loginForm.controls['password']; }

  loginUser() {
    const { email, password } = this.loginForm.value;
    this.authService.login(email as string, password as string).subscribe({
      next: (response) => {
        const token = response.secret;
        if (token) {
          this.authService.setSecret(token); // Stocke le token
          this.router.navigate(['/movies']).then(() => {
            this.msgService.add({ severity: 'success', summary: 'Connexion réussie', detail: 'Vous êtes maintenant connecté(e).' });
          });
        } else {
          // Gestion de l'absence de token dans la réponse
          this.msgService.add({ severity: 'error', summary: 'Erreur', detail: 'Mot de passe invalide' });
        }
      },
      error: (err) => {
        let detailMsg = 'La connexion a échoué: email invalide.';
        if (err.error && err.error.detail) {
          detailMsg = err.error.detail;
        }
        this.msgService.add({ severity: 'error', summary: 'Erreur', detail: detailMsg });
      }
    });
  }


  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
