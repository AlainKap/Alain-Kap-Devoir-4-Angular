import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { AuthService } from '../../services/auth.service';
import { DividerModule } from 'primeng/divider';
import { CardModule } from 'primeng/card';
import { MessageService } from 'primeng/api';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { passwordMatchValidator } from '../../shared/password-match.directive';
import {  startsWithCapital } from '../../shared/capital-name.directive';
import { User } from '../../interfaces/auth';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    InputTextModule,
    DividerModule,
    ButtonModule,
    ReactiveFormsModule,
    CardModule,
    FormsModule,
  ],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
})
export class RegisterComponent {
  authService = inject(AuthService);
  route = inject(ActivatedRoute);
  messageService = inject(MessageService);
  router = inject(Router);
  fb = inject(FormBuilder);

  registerForm = this.fb.group(
    {
      name: [
        '',
        {
          validators: [Validators.required, Validators.minLength(2), startsWithCapital()],
          updateOn: 'blur',
        },
      ],
      email: [
        '',
        {
          validators: [
            Validators.required,
            Validators.email,
            Validators.minLength(7),
          ],
          updateOn: 'blur',
        },
      ],
      password: [
        '',
        {
          validators: [Validators.required,, Validators.minLength(8), Validators.pattern(/^\S*$/)],
          updateOn: 'blur',
        },
      ],
      confirmPassword: [
        '',
        { validators: [Validators.required], updateOn: 'blur' },
      ],
    },
    {
      validators: passwordMatchValidator,
      updateOn: 'blur',
    }
  );

  get name() {
    return this.registerForm.controls['name'];
  }

  get email() {
    return this.registerForm.controls['email'];
  }

  get password() {
    return this.registerForm.controls['password'];
  }

  get confirmPassword() {
    return this.registerForm.controls['confirmPassword'];
  }

  submitDetails() {
    if (this.registerForm.valid) {
      const postData = { ...this.registerForm.value };
      delete postData.confirmPassword;
      this.authService.registerUser(postData as User).subscribe({
        next: (response) => {
          console.log(response);
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Insription réussie',
          });
          this.router.navigate(['login']);
        },
        error: (error) => {
          console.error(error);
          let detail = 'Il y a eu un stut';
          if (error.error && typeof error.error.message === 'string') {
            detail = error.error.message;
          }
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: detail,
          });
        },
      });
    } else {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Le formulaire doit être rempli correctement.',
      });
    }
  }
}
