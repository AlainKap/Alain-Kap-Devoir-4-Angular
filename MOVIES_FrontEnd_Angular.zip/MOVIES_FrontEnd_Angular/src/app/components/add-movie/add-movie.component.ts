import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormsModule,
  ReactiveFormsModule,
  AbstractControl,
} from '@angular/forms';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../interfaces/movie.interface';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { AuthService } from '../../services/auth.service';
import { RouterLink } from '@angular/router';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogConfig } from 'primeng/dynamicdialog';


@Component({
  selector: 'app-add-movie',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
    InputTextareaModule,
    CalendarModule,
    DropdownModule,
    InputNumberModule,
    ButtonModule,
    RouterLink,
    DialogModule,
  ],
  templateUrl: './add-movie.component.html',
  styleUrl: './add-movie.component.scss',
})
export class AddMovieComponent {
  service = inject(MovieService);
  auth = inject(AuthService);
  config = inject(DynamicDialogConfig);
  movies: any = [];
  route = inject(ActivatedRoute);
  messageService = inject(MessageService);
  router = inject(Router);
  fb = inject(FormBuilder);
  id?: number;
  isNew = true;
  isEditable = false;
  count = 0;
  page = 1;
  totalPage = 0;
  movie!: Movie;

  form = this.fb.group({
    nom: [
      '',
      {
        validators: [Validators.required, Validators.minLength(2)],
        updateOn: 'blur',
      },
    ],
    annee: [
      '',
      {
        validators: [
          Validators.required,
          Validators.min(1890),
          Validators.pattern(/^(189[1-9]|19\d{2}|20\d{2})$/),
        ],
        updateOn: 'blur',
      },
    ],
    realisateur: [
      '',
      {
        validators: [Validators.required, this.validateRealisateur],
        updateOn: 'blur',
      },
    ],
    synopsis: [
      '',
      {
        validators: [
          Validators.required,
          Validators.minLength(5),
        ],
        updateOn: 'blur',
      },
    ],
  });

  validateRealisateur(control: AbstractControl): { [key: string]: any } | null {
    const isValid = control.value && control.value.split(' ').length >= 2;
    return isValid ? null : { invalidRealisateur: true };
  }

  constructor() {
    this.initializeForm();
  }

  ngOnInit() {
    if (this.config.data && this.config.data.movie) {
      this.isNew = false;
      this.movie = this.config.data.movie;
      this.id = this.movie.id;
      this.initializeFormWithMovieData(this.movie);
    }
  }


  initializeForm() {
    this.form = this.fb.group({
      nom: ['', [Validators.required, Validators.minLength(2)]],
      annee: ['', [Validators.required, Validators.min(1890), Validators.pattern(/^(189[1-9]|19\d{2}|20\d{2})$/)]],
      realisateur: ['', [Validators.required, this.validateRealisateur]],
      synopsis: ['', [Validators.required, Validators.minLength(5)]],
    });
  }

  initializeFormWithMovieData(movie: Movie) {
    const movieData = {
      ...movie,
      annee: movie.annee ? movie.annee.toString() : ''
    };

    this.form.patchValue(movieData);
  }

  read(id: string) {
    this.service.read(id).subscribe((result: any) => {
      this.form.controls.nom.setValue(result.data.nom);
      this.form.controls.annee.setValue(result.data.annee);
      this.form.controls.realisateur.setValue(result.data.realisateur);
      this.form.controls.synopsis.setValue(result.data.synopsis);
      this.form.enable();
    });
  }

  private buildMovie(userId: number): Movie {
    if (!userId) {
      throw new Error("L'ID de l'utilisateur est introuvable");
    }
    const anneeValue = this.form.controls.annee.value;
    let annee: number | null = anneeValue ? parseInt(anneeValue, 10) : null;
    let movie: Movie = {
      id: this.id,
      nom: this.form.controls.nom.value,
      annee: annee,
      realisateur: this.form.controls.realisateur.value,
      synopsis: this.form.controls.synopsis.value,
      userId: userId,
    };
    if (this.id !== undefined) {
      movie.id = this.id;
    }
    return movie;
  }

  create() {
    const userId = this.auth.getUserId();
    if (!userId) {
      console.error("L'ID de l'utilisateur est introuvable");
      return;
    }
    let annee: number | null = null;
    const anneeValue = this.form.controls.annee.value;
    if (anneeValue !== null) {
      annee = parseInt(anneeValue);
    }
    const nom = this.form.controls.nom.value;
    const realisateur = this.form.controls.realisateur.value;
    const synopsis = this.form.controls.synopsis.value;
    const movie: Movie = {
      //id: this.id ?? -1,
      nom: nom,
      annee: annee,
      realisateur: realisateur,
      synopsis: synopsis,
      userId: +userId,
      createdAt: new Date(),
      updatedAt: new Date(),

    };
    this.service.addmovie(movie).subscribe({
      next: (result) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Succès',
          detail: 'Film ajouté avec succès',
        });
        this.router.navigate(['/movies']);
      },
      error: (error) => {
        console.error("Erreur lors de l'ajout du film:", error);
        this.messageService.add({
          severity: 'error',
          summary: 'Erreur',
          detail: "Erreur lors de l'ajout du film",
        });
      },
    });
  }

  edit() {
    if (this.isNew) {
      console.error('Nouveau film, rien à éditer');
      return;
    }
  if (!this.id) {
    console.error('L\'ID du film est introuvable lors de l\'édition');
    return;
  }
    // Récupère l'userId stocké
    const userIdString = this.auth.getUserId();
    const userId = userIdString ? Number(userIdString) : null;
    if (!userId) {
      console.error("L'ID de l'utilisateur est introuvable lors de l'édition");
      return;
    }
    const movieToUpdate = this.buildMovie(userId);
    if (!movieToUpdate.id) {
      console.error('Movie is undefined or does not have an id');
      return;
    }
    this.update(movieToUpdate);
  }

  update(movieToUpdate: Movie) {
    if (!movieToUpdate || movieToUpdate.id === undefined) {
      console.error('Movie is undefined or does not have an id');
      return;
    }
    this.service.updatemovie(movieToUpdate, movieToUpdate.id).subscribe({
      next: (result) => {
        console.log('Film mis à jour avec succès:', result);
        this.router.navigate(['/movies']);
        this.messageService.add({
          severity: 'success',
          summary: 'Mise à jour réussie',
          detail: 'Le film a été mis à jour avec succès',
        });
      },
      error: (error) => {
        console.error('Erreur lors de la mise à jour du film:', error);
        this.messageService.add({
          severity: 'error',
          summary: 'Erreur',
          detail: 'Une erreur est survenue lors de la mise à jour du film',
        });
      },
    });
  }

  display: boolean = false;

  showDialog() {
      this.display = true;
  }

}
