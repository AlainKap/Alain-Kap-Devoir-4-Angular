export interface Movie {
  id?: number;
  nom: string | null;
  annee: number | null;
  realisateur: string | null;
  synopsis: string | null;
  userId: number;
  // userEmail: string;
  createdAt?: Date | null;
  updatedAt?: Date | null;
}
